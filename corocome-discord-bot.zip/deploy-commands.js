require("dotenv").config();

const {
  REST,
  Routes,
  SlashCommandBuilder
} = require("discord.js");

const commands = [
  new SlashCommandBuilder()
    .setName("enquete")
    .setDescription("Cria uma enquete com votação por botões.")
    .addStringOption(o => o.setName("pergunta").setDescription("Pergunta da enquete").setRequired(true))
    .addStringOption(o => o.setName("opcao1").setDescription("Primeira opção").setRequired(true))
    .addStringOption(o => o.setName("opcao2").setDescription("Segunda opção").setRequired(true))
    .addStringOption(o => o.setName("opcao3").setDescription("Terceira opção").setRequired(false))
    .addStringOption(o => o.setName("opcao4").setDescription("Quarta opção").setRequired(false))
    .addStringOption(o => o.setName("opcao5").setDescription("Quinta opção").setRequired(false)),

  new SlashCommandBuilder()
    .setName("recrutamento")
    .setDescription("Publica o alto recrutamento da COROCOME."),

  new SlashCommandBuilder()
    .setName("fechar-enquete")
    .setDescription("Fecha uma enquete e mostra o resultado.")
    .addStringOption(o => o.setName("id").setDescription("ID da enquete").setRequired(true))
].map(c => c.toJSON());

async function main() {
  if (!process.env.DISCORD_TOKEN || !process.env.CLIENT_ID) {
    throw new Error("Preencha DISCORD_TOKEN e CLIENT_ID no arquivo .env");
  }

  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

  if (process.env.GUILD_ID) {
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commands }
    );
    console.log("✅ Comandos registrados no servidor.");
  } else {
    await rest.put(
      Routes.applicationCommands(process.env.CLIENT_ID),
      { body: commands }
    );
    console.log("✅ Comandos registrados globalmente.");
  }
}

main().catch(console.error);
