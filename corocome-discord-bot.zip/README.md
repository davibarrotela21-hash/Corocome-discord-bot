# 🤖 Bot COROCOME — Discord

Bot com:
- `/enquete` — enquete com 2 a 5 opções e votação por botões.
- `/recrutamento` — publica o alto recrutamento da COROCOME.
- `/fechar-enquete` — mostra o resultado e encerra a enquete.
- Recrutamento com vagas ilimitadas.
- **Não inclui benefícios de Glock/50K.**

## 1. Preparar
Instale Node.js 20 ou superior.

Depois, nesta pasta:
```bash
npm install
```

## 2. Configurar
Renomeie `.env.example` para `.env` e preencha:

```env
DISCORD_TOKEN=SEU_TOKEN_DO_BOT
CLIENT_ID=1548585353907015720
GUILD_ID=ID_DO_SEU_SERVIDOR
```

⚠️ NUNCA publique o `DISCORD_TOKEN` nem envie esse token para ninguém.

## 3. Registrar os comandos
```bash
npm run deploy
```

Se `GUILD_ID` estiver preenchido, os comandos são registrados diretamente nesse servidor.

## 4. Ligar o bot
```bash
npm start
```

Enquanto o processo estiver ligado, o bot ficará online.

## 5. Comandos

### Enquete
Exemplo:
```text
/enquete pergunta:Quem deve ser promovido? opcao1:Sim opcao2:Não opcao3:Talvez
```

### Recrutamento
```text
/recrutamento
```

Somente quem tem **Gerenciar Servidor** pode publicar o recrutamento.

### Fechar enquete
```text
/fechar-enquete id:ID_DA_ENQUETE
```

Observação: o ID da enquete aparece no estado interno do bot. Para uso simples, o comando de fechamento pode ser substituído futuramente por um botão "Encerrar".
