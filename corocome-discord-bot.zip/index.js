require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  PermissionsBitField,
  Events
} = require("discord.js");

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

// Enquetes ficam em memória enquanto o bot estiver ligado.
const polls = new Map();

const recrutamento = [
  ["🚷 1. O que é RDM?", "Explique com suas palavras."],
  ["🚗 2. O que é VDM?", "Explique com suas palavras."],
  ["💪 3. O que é Power Gaming (PG)?", "Explique com suas palavras."],
  ["🖥️ 4. O que é Meta Gaming (MG)?", "Explique com suas palavras."],
  ["🔌 5. O que é Combat Log (CL)?", "Explique com suas palavras."],
  ["⚖️ 6. Se um superior dá uma ordem, o que você faz?", "Explique sua postura."],
  ["📋 7. Compromisso — Seguir todas as regras internas?", "Responda se está disposto e explique."],
  ["🤝 8. Conflito interno com membro — como age?", "Explique como resolveria."],
  ["⚠️ 9. Erro grave — Como se apresenta à liderança?", "Explique o que faria."],
  ["🎯 10. Prioridade — Interesse próprio vs. Nome da Tropa?", "Explique sua escolha."],
  ["👀 11. Membro prejudicando o grupo — o que faz?", "Explique como agiria."],
  ["⚔️ 12. Base cercada por inimigos — o que você faz?", "Explique sua postura dentro das regras do servidor."],
  ["🏆 13. Por que você escolheu a COROCOME — e o que você traz de diferente?", "Responda com detalhes."]
];

function isStaff(interaction) {
  return interaction.memberPermissions?.has(PermissionsBitField.Flags.ManageGuild);
}

client.once(Events.ClientReady, (c) => {
  console.log(`✅ ${c.user.tag} está online.`);
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === "enquete") {
        const pergunta = interaction.options.getString("pergunta", true);
        const opcoes = [
          interaction.options.getString("opcao1", true),
          interaction.options.getString("opcao2", true),
          interaction.options.getString("opcao3"),
          interaction.options.getString("opcao4"),
          interaction.options.getString("opcao5")
        ].filter(Boolean);

        if (opcoes.length < 2 || opcoes.length > 5) {
          return interaction.reply({ content: "❌ A enquete precisa ter de 2 a 5 opções.", ephemeral: true });
        }

        const pollId = `${interaction.guildId}-${Date.now()}`;
        polls.set(pollId, {
          question: pergunta,
          options: opcoes,
          votes: new Map()
        });

        const embed = new EmbedBuilder()
          .setTitle("📊 ENQUETE")
          .setDescription(`**${pergunta}**\n\n` + opcoes.map((o, i) => `${i + 1}. ${o}`).join("\n"))
          .setFooter({ text: `Criada por ${interaction.user.username} • Cada pessoa pode votar em uma opção` });

        const row = new ActionRowBuilder().addComponents(
          opcoes.map((o, i) =>
            new ButtonBuilder()
              .setCustomId(`poll:${pollId}:${i}`)
              .setLabel(o.length > 70 ? o.slice(0, 67) + "..." : o)
              .setStyle(ButtonStyle.Primary)
          )
        );

        await interaction.reply({ embeds: [embed], components: [row] });
        return;
      }

      if (interaction.commandName === "recrutamento") {
        if (!isStaff(interaction)) {
          return interaction.reply({
            content: "❌ Você precisa ter a permissão **Gerenciar Servidor** para publicar o alto recrutamento.",
            ephemeral: true
          });
        }

        const descricao = [
          "## 🎖️ ALTO RECRUTAMENTO — COROCOME",
          "",
          "### 📚 PARTE I — CONHECIMENTOS DE ROLEPLAY",
          ...recrutamento.slice(0, 5).flatMap(([q, a]) => [`**${q}**`, `> ${a}`, ""]),
          "### ⚖️ PARTE II — DISCIPLINA E POSTURA",
          ...recrutamento.slice(5).flatMap(([q, a]) => [`**${q}**`, `> ${a}`, ""]),
          "### ♾️ VAGAS",
          "**Vagas ilimitadas.**",
          "",
          "📌 **Como responder:** envie as respostas numeradas de **1 a 13**, na ordem.",
          "🏆 **Boa sorte no recrutamento!**"
        ].join("\n");

        const embed = new EmbedBuilder()
          .setTitle("🎖️ ALTO RECRUTAMENTO — COROCOME")
          .setDescription(descricao)
          .setTimestamp();

        await interaction.reply({ embeds: [embed] });
        return;
      }

      if (interaction.commandName === "fechar-enquete") {
        if (!isStaff(interaction)) {
          return interaction.reply({ content: "❌ Você precisa ter **Gerenciar Servidor** para fechar uma enquete.", ephemeral: true });
        }

        const pollId = interaction.options.getString("id", true);
        const poll = polls.get(pollId);

        if (!poll) {
          return interaction.reply({ content: "❌ Enquete não encontrada ou o bot foi reiniciado.", ephemeral: true });
        }

        const counts = poll.options.map((_, i) => {
          let n = 0;
          for (const choice of poll.votes.values()) if (choice === i) n++;
          return n;
        });

        const total = counts.reduce((a, b) => a + b, 0);
        const resultado = poll.options.map((o, i) => {
          const pct = total ? Math.round((counts[i] / total) * 100) : 0;
          return `**${o}** — ${counts[i]} voto(s) (${pct}%)`;
        }).join("\n");

        const embed = new EmbedBuilder()
          .setTitle("📊 RESULTADO DA ENQUETE")
          .setDescription(`**${poll.question}**\n\n${resultado}\n\n👥 Total de votos: **${total}**`);

        polls.delete(pollId);
        await interaction.reply({ embeds: [embed] });
        return;
      }
    }

    if (interaction.isButton() && interaction.customId.startsWith("poll:")) {
      const [, pollId, optionIndexRaw] = interaction.customId.split(":");
      const poll = polls.get(pollId);

      if (!poll) {
        return interaction.reply({ content: "❌ Esta enquete não está mais ativa.", ephemeral: true });
      }

      const optionIndex = Number(optionIndexRaw);
      poll.votes.set(interaction.user.id, optionIndex);

      const counts = poll.options.map((_, i) => {
        let n = 0;
        for (const choice of poll.votes.values()) if (choice === i) n++;
        return n;
      });

      const total = counts.reduce((a, b) => a + b, 0);
      const embed = new EmbedBuilder()
        .setTitle("📊 ENQUETE")
        .setDescription(
          `**${poll.question}**\n\n` +
          poll.options.map((o, i) => `${i + 1}. ${o} — **${counts[i]}** voto(s)`).join("\n") +
          `\n\n👥 Total: **${total}**`
        )
        .setFooter({ text: "Você pode trocar seu voto clicando em outra opção." });

      await interaction.update({ embeds: [embed] });
    }
  } catch (error) {
    console.error(error);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({ content: "❌ Ocorreu um erro. Tente novamente.", ephemeral: true }).catch(() => {});
    }
  }
});

client.login(process.env.DISCORD_TOKEN);
